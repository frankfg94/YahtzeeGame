package core;

public enum ComboType 
{
	One,
	Two,
	Three,
	Four,
	Five,
	Six,
	Brelan,
	Square,
	FullHouse,
	SmallStraight,
	LargeStraight,
	Yahtzee,
	Chance
	}
