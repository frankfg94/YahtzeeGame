package core;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class Main 
{	
	public static void main(String[] args)
	{
		// Welcome to the Yahtzee GITHUB project
		//TestCombos(10000);
		YahtzeeGame game = new YahtzeeGame();
		game.ShowMenu();

	}
	
	/**Function used for batch combination testing, results are stored in the file Testing.txt, an instance of the game needs to be launched first
	 * @param nbOfTests : the number of tests that needs to be done
	 * */
	@SuppressWarnings("unused")								// We don't need to add warnings if we don't use a method related to testing
	private static void TestCombos(final int nbOfTests)
	{
		YahtzeeGame testGame = new YahtzeeGame();
		Player p = new Player("Test Player");
		PrintStream printStream;
		try {
			printStream = new PrintStream(new FileOutputStream("Testing.txt"));
			System.setOut(printStream);
		} catch (FileNotFoundException e) {
			System.out.println("Error redirecting output to textFile");
		}
		for(int i = 0; i < nbOfTests; i++)
		{
			System.out.println("\n\n///////\t\tTest N�" + (i+1) + "\t\t////////\n");
			p.AskToRollDicesSkip();
			p.ShowAvailableCombos();
		}
	}
	 
}
