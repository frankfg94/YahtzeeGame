package core;
import core.Combo;
import java.util.Random;
/**
 *
 * @author f_gillio
 */
public class PlayerAI extends Player
{
	public PlayerAI(String name)
	{
    	super(name);
	}
	
	
	@Override
   public void AskToRollDicesAgain()
 {
  System.out.println("Choose dice (1-5) to roll specific dices");
  System.out.println("Choose 0 to sacrifice");
  int diceID = -1; //  id used to designate errors
  
  while (diceID != 9)
  {
  try
  {
            	Random r = new Random();
  diceID = r.nextInt(5);
            	diceID++;
  if (diceID <= 5 && diceID >= 1)
  {
  core.YahtzeeGame.dices[diceID - 1].Roll();
  System.out.println("\nYour dice " + diceID + " has been rolled");
  }
  else if(diceID == 0)
  {
   manualSacrifice = true;
   AskToSacrificeCombo();
   return;
  }
  else if (diceID != 9 && (diceID > 5 || diceID < 1))
  {
  System.out.println("Please enter between 5 and 1 or 9");
  }
  }
  catch (NumberFormatException e)
  {
  System.out.println("Unrecognized input, please enter a number");
  }
  if(diceID != 9)
  {
   System.out.println("Choose dice (1-5) to roll specific dices");
   System.out.println( "Use 9 to stop rolling");
  }
  }
  return;
 }

 
 
  @Override
  public void AskToSacrificeCombo()
  {
   DisplayAvailableCombos("\t\t Choose the combo you want to disable");
   sacrificeCount = 0;
   for(Combo c : combos)
	   if(c.isAvailable)
	   {
		   sacrificeCount++;
	   }
   sacrificeChoice = sacrificeCount-1; // we substract 1 because we can sacrifice starting from 0
   SacrificeAndDisplayCombo();
  }
 
 
  @Override
  protected void AskToChooseCombo(int remainingRolls)
	{
		if(manualSacrifice) // We check if the sacrifice is a voluntary act, then we can't choose anymore a combo 
		{
			manualSacrifice = false;
			return;					
		}
		DisplayChooseMessageCombo();

			if (remainingRolls > 0)
				System.out.println("\nChoice "+ comboIndex   +" : Roll Again \n"); // If the player still has the right to roll dices, propose this choice to him
			if(comboIndex <= 0) // No combo was detected 
			{
				AskToSacrificeCombo();
			}
			else	// if at least one combo is detected
			{
				if(comboIndex > 1)
				{
					comboChoice = comboIndex-2;
				}
				else if(comboIndex == 1)
				{
					comboChoice = 0;
				}
				
				System.out.println(name + " : " + comboChoice );
				if(comboChoice == comboIndex && remainingRolls > 0) // Special case if we want to roll dices again
				{
				AskToRollDicesAgain();
				AskToChooseCombo(remainingRolls-1);
				}
				else	// if not, simply use the combo (add it's score and disable it)
				{
				UseSelectedCombo();
				}
		}
	}
		
}

